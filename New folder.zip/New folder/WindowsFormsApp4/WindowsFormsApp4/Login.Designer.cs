﻿namespace WindowsFormsApp4
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.Label();
            this.Register = new System.Windows.Forms.LinkLabel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.Enter = new System.Windows.Forms.Button();
            this.EnterAsAdmin = new System.Windows.Forms.LinkLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(41, 49);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(217, 20);
            this.textBox1.TabIndex = 0;
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username.Location = new System.Drawing.Point(38, 19);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(107, 16);
            this.Username.TabIndex = 1;
            this.Username.Text = "Username / Email";
            // 
            // Register
            // 
            this.Register.AutoSize = true;
            this.Register.LinkColor = System.Drawing.Color.OliveDrab;
            this.Register.Location = new System.Drawing.Point(88, 216);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(129, 13);
            this.Register.TabIndex = 2;
            this.Register.TabStop = true;
            this.Register.Text = "Don`t Have an Account? ";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(41, 117);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(217, 20);
            this.textBox2.TabIndex = 3;
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password.Location = new System.Drawing.Point(38, 87);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(62, 16);
            this.Password.TabIndex = 4;
            this.Password.Text = "Password";
            // 
            // Enter
            // 
            this.Enter.BackColor = System.Drawing.Color.OliveDrab;
            this.Enter.Font = new System.Drawing.Font("Yu Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enter.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Enter.Location = new System.Drawing.Point(41, 158);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(217, 43);
            this.Enter.TabIndex = 5;
            this.Enter.Text = "Enter";
            this.Enter.UseVisualStyleBackColor = false;
            // 
            // EnterAsAdmin
            // 
            this.EnterAsAdmin.AutoSize = true;
            this.EnterAsAdmin.LinkColor = System.Drawing.Color.Chocolate;
            this.EnterAsAdmin.Location = new System.Drawing.Point(109, 244);
            this.EnterAsAdmin.Name = "EnterAsAdmin";
            this.EnterAsAdmin.Size = new System.Drawing.Size(78, 13);
            this.EnterAsAdmin.TabIndex = 6;
            this.EnterAsAdmin.TabStop = true;
            this.EnterAsAdmin.Text = "Enter as Admin";
            this.EnterAsAdmin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.EnterAsAdmin_LinkClicked);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(0, 281);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(295, 110);
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 391);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.EnterAsAdmin);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.textBox1);
            this.Name = "Login";
            this.Text = "Login";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.LinkLabel Register;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Button Enter;
        private System.Windows.Forms.LinkLabel EnterAsAdmin;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}