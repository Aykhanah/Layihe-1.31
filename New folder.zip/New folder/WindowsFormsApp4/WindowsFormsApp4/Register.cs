﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void Password_Click(object sender, EventArgs e)
        {
        
        }

        private void Username_Click(object sender, EventArgs e)
        {

        }
    }
}
