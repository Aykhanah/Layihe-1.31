﻿USE Hostel;

create table Hostel(
Id int primary key identity,
Name nvarchar(200),
)

create table Room(
Id int primary key identity,
Number int
)

--create table ReservationMade(
----ReservationMadeBy nvarchar(100),
--ReservationID int NOT NULL,
--FOREIGN KEY (ReservationID) REFERENCES Reservation(ReservationID)
--)

create table Bed(
Id int primary key identity,
Type nvarchar(100),
)
--insert into Bed
--values ('Single', 'Double')

create table Customer(
Id int primary key identity,
Firstname nvarchar(100),
lastname nvarchar(100),
IdentityCard nvarchar(100),
Birthdate datetime,
TelephoneNumbeer nvarchar(100),
Email nvarchar(200)
)

create table Admin(
Id int primary key identity,
Username nvarchar(100),
Password nvarchar(100),
)

create table Cost(
Id int primary key identity,
Cost int,
ForWhat nvarchar(200)
)

create table Reservation(
Id int primary key identity,
RoomID int references Room(Id),
BedID int references Bed(Id),
CustomerID int references Customer(Id),
ReservationStarting datetime,
ReservationEnding datetime,
TotalPrice int 
)

create table Gain(
Id int primary key identity,
Gain int,
FromWhat nvarchar(200)
ReservationID int references Reservation(Id),
)
